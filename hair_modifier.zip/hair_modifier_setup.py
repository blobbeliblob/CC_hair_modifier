from shutil import copyfile
import json
import os

def main():
	#load data from file
	try:
		with open('hair_modifier_data.json') as f:
			data = json.load(f)
	except Exception as e:
		print('\nfile "hair_modifier_data.json" could not be loaded!\n')
		print("error: "+str(e))
		input("press ENTER to exit")
		return
	files = data["files"]
	
	#copy assets to mods directory
	for f in files:
		src_dir = '\\'.join(f.split('\\')[0:-1])
		dest_dir = "mods\\" + src_dir
		if not os.path.isdir(dest_dir):
			os.makedirs(dest_dir)
		copyfile(f, "mods\\" + f)
		print("added: mods\\" + f)
	#make a backup directory
	for f in files:
		backup_dir = "backup\\" + src_dir
		if not os.path.isdir(backup_dir):
			os.makedirs(backup_dir)
		copyfile(f, "backup\\" + f)
		print("added: backup\\" + f)
	
	#copy hair_replacer to mods directory
	copyfile("hair_modifier.py", "mods/hair_modifier.py")
	copyfile("hair_modifier_data.json", "mods/hair_modifier_data.json")
	copyfile("hair_modifier_data_backup.json", "mods/hair_modifier_data_backup.json")
		
	input("press ENTER to exit")
	return
	
main()