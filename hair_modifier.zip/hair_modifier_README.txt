This document serves the purpose of explaining how to use the hair_modifier script to change the
appearance of Lea in CrossCode

step 1

make sure you have Python installed on your computer, this can be checked by checked in the terminal
by typing 'python'

Python can be downloaded from https://www.python.org/downloads/

step 2

make sure you have Pillow installed, this can be checked by typing 'pip install pillow' in the terminal
or running the included 'install PIL.bat' file (if using Windows)

step 3 (optional)

run the 'hair_modifier_setup.py' file to create a mod directory as well as a backup directory, 
this way the following steps can be done from the mod directory

step 4

the file 'hair_modifier_data.json' should not be edited!
also make sure to not edit Lea's hair color without the use of the hair_modifier script!

step 5

run the 'hair_modifier.py' file
when asked what to do, write 'hair' (without quotes)
press ENTER
when asked for a color, write a number between 0 and 360 (this number refers to the hue of the color)
writing 'default' (without quotes) instead resets Lea's hair color to the original
press ENTER

step 6 (possibly optional)

if step 3 was done and the script has been run from the mod directory, copy the 'assets' folder and
paste it in the game folder, overwrite all files when asked

step 7 (possibly optional)

if you want to reset the hair_color and step 3 was done, this can be done by copying the 'assets' folder 
in the backup directory and pasting it in the game folder, overwrite all files when asked