import os
import json
from PIL import Image
import colorsys

#returns True if pixels a & b are the same
def compare_pixels(a, b):
	if a[0] == b[0] and a[1] == b[1] and a[2] == b[2]:
		return True
	return False

#returns rgb values converted to hsv
def rgb_to_hsv(pix):
	return colorsys.rgb_to_hsv(pix[0], pix[1], pix[2])

#returns hsv values converted to rgb
def hsv_to_rgb(pix):
	return colorsys.hsv_to_rgb(pix[0], pix[1], pix[2])

#old and new are lists of rgb values, see hair_modifier_data.json
def replace_colors(filepath, old, new):
	pic = Image.open(filepath)
	width, height = pic.size
	for i in range(len(old)):
		for x in range(width):
			for y in range(height):
				if compare_pixels(pic.getpixel((x, y)), old[i]):
					pic.putpixel((x, y), tuple(new[i]))
	pic.save(filepath)

def change_hair_color(filepath, data):
	old = [data["current_hair"][c] for c in data["current_hair"]]
	new = [data["modified_hair"][c] for c in data["modified_hair"]]
	replace_colors(filepath, old, new)

def main():
	'''
	#find all files to be modified
	files = list()
	print("searching for files...this may take a while")
	for (dirpath, dirnames, filenames) in os.walk('.'):
		paths = [os.path.join(dirpath, file) for file in filenames]
		files += [path for path in paths if path.endswith('.png')]
	print("Files discovered:\n")
	for f in files:
		print(f)
	'''
	
	#load data from file
	try:
		with open('hair_modifier_data.json') as f:
			data = json.load(f)
	except Exception as e:
		print('\nfile "hair_modifier_data.json" could not be loaded!\n')
		print("error: "+str(e))
		input("press ENTER to exit")
		return
		
	files = data["files"]
	
	#process user input
	print("\nPossible commands:\n\nhair:\tchange hair colors\n")
	command = input("What do you want to do?\n")
	while command is not "":
		if(command == 'hair'):
			color = input("Which color? (number between 0 and 360, or default to reset)\n")
			print("configuring color...")
			if color == "default":
				data["modified_hair"] = data["default_hair"]
			else:
				color = int(color)
				for i in data["default_hair"]:
					pix = data["default_hair"][i]
					pix = list(rgb_to_hsv(pix))
					pix[0] = color/360.0
					pix = list(hsv_to_rgb(pix))
					for k in range(len(pix)):
						pix[k] = int(pix[k])
					data["modified_hair"][i] = list(pix)
			print("ok")
			print("starting file modifications...")
			for f in files:
				change_hair_color(f, data)
				print("modified: " + f)
			print("ok")
			data["current_hair"] = data["modified_hair"]
			try:
				with open('hair_modifier_data.json', 'w') as f:
					json.dump(data, f, indent = '\t')
			except Exception as e:
				print('\ncould not save new data to "hair_modifier_data.json"\n')
				print("error: "+str(e))
				input("press ENTER to continue\n")
		command = input("\nWhat do you want to do?\n")
	input("press ENTER to exit")
	return
main()